---
title: Tai Chi download
sidebar: false
---

# Download

[中文用户在这里下载](/zh/download)

## Tai Chi

::: tip
Tai Chi app current version: **5.7.7**
:::

Install TaiChi APP first, then you can use it to run modules.

- [**Download Address**][stable1]
- [**Download Address(github)**][stable2]

If you want to download modules, go [Module Download](/module/)。

## TaiChi Magisk module

::: tip
Magisk module current version: **6.0.0**
:::

If you want to use Magisk mode of TaiChi, you must flash Magisk module of TaiChi first. Here the modules:

- Magisk 17.0+：[Download][taichi-magisk17]
- Magisk 15.0 ~ 16.x ：[Download][taichi-magisk16]

By the way, you can follow [TaiChi-Magisk][taichi-magisk] to get latest news.

[stable1]: https://tc5.us/file/19604958-414508709
[stable2]: https://github.com/taichi-framework/TaiChi/releases
[taichi-magisk17]: https://tc5.us/file/19604958-402348911
[taichi-magisk16]: https://www.lanzous.com/i37r5kh
[taichi-magisk]: https://github.com/taichi-framework/TaiChi-Magisk/releases
