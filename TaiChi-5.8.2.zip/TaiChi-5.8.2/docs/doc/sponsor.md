The maintaining of Tai Chi costs lots of my time, if you appreciate my work, buy me a cup of coffee! :)

## Paypal

[![Paypal Me](/paypal.png)](https://paypal.me/virtualxposed)

## Bitcoin

[39Wst8oL74pRP2vKPkPihH6RFQF4hWoBqU](https://www.blockchain.com/btc/payment_request?address=39Wst8oL74pRP2vKPkPihH6RFQF4hWoBqU)

## Alipay

<img src="/alipay.jpg" alt="alipay" width="240" height="364">

## Weixin

<img src="/weixin.png" alt="weixin" width="200" height="274">

## QQ

<img src="/qq.png" alt="weixin" width="240" height="360">
