# TaiChi Download

[中文用户在这里下载](download_cn.md)

## TaiChi APP

Install TaiChi APP first, then you can use it to run modules.

- [**TaiChi Download Address 1**][stable1]

If you want to download modules, go [Module Download](/module/index)。

## TaiChi Magisk module

If you want to use Magisk mode of TaiChi, you must flash Magisk module of TaiChi first. Here the modules:

- Magisk 17.0+：[Download][taichi-magisk17]
- Magisk 15.0 ~ 16.x ：[Download][taichi-magisk16]

By the way, you can follow [TaiChi-Magisk][taichi-magisk] to get latest news.

[stable1]: https://tc5.us/file/19604958-402658311
[stable2]: https://github.com/taichi-framework/TaiChi/releases
[taichi-magisk17]: https://tc5.us/file/19604958-402348911
[taichi-magisk16]: https://www.lanzous.com/i37r5kh
[taichi-magisk]: https://github.com/taichi-framework/TaiChi-Magisk/releases
