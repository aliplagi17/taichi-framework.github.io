# Changelog

## 5.7.7

1. Support swith launcher icon