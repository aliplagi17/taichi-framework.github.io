![logo](_media/logo.svg)

# Tai Chi

> A framework to use Xposed module with root or non-root.

* Fully support Android 5.0 ~ 10
* Support Non-root mode
* Hard to be detected
* Stable & Smoothly

[Download](/download)
[Quick Start](/getting_started)

![color](#3f3f3f)