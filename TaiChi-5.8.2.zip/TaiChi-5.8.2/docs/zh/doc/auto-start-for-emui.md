# 华为系统如何设置自启动

以下是跳转到华为自启动界面的截图：

<img src="https://github.com/taichi-framework/TaiChi/blob/master/arts/emui1.jpeg" width="250" />
<img src="https://github.com/taichi-framework/TaiChi/blob/master/arts/emui2.jpeg" width="250" />


注意：

1. 注意区分自动管理和手动管理。**勾选之后如果是自动管理，那么不要勾选！！！**
2. 设置为**手动管理**之后，把三个选项都勾上！！