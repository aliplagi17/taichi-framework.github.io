维护 太极 ☯️ 耗费了我大量时间，如果你喜欢这个项目，可以赞助我买包辣条。

## Paypal

[![Paypal Me](/paypal.png)](https://paypal.me/virtualxposed)

## Bitcoin

[39Wst8oL74pRP2vKPkPihH6RFQF4hWoBqU](https://www.blockchain.com/btc/payment_request?address=39Wst8oL74pRP2vKPkPihH6RFQF4hWoBqU)

## Alipay

<img src="/alipay.jpg" alt="alipay" width="240" height="364">

## Weixin

<img src="/weixin.png" alt="weixin" width="200" height="274">

## QQ

<img src="/qq.png" alt="weixin" width="240" height="360">
