---
home: true
heroImage: /logo.svg
heroText: 太极
tagline: 一个可以免 Root 运行的类 Xposed 框架
actionText: 了解更多 →
actionLink: /zh/doc/
actionText2: 下载
actionLink2: download
features:
  - title: 支持最新系统
    details: 完美支持包括 Android 5.0~10 在内的几乎所有机型（如华为、三星、小米，Oppo和 Vivo 等)。
  - title: 可以免 Root 模式运行
    details: 无需 Root 也可以体验各种插件的强大功能，有 Root 之后也能解锁更多的能力。
  - title: 稳定、流畅、安全
    details: 默认白名单，太极之外的App 无任何影响；弱侵入性不易被检测；不明来源的模块无法使用保障安全。
footer: Copyright © 2018-present weishu
---
