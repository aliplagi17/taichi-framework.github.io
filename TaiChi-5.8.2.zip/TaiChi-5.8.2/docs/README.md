---
home: true
heroImage: /logo.svg
heroText: Tai Chi
tagline: A Rootless Xposed-Style Framework
actionText: Learn More →
actionLink: /doc/
actionText2: Download
actionLink2: download
features:
  - title: Supporting latest Android
    details: Fully support Android 5.0 ~ 10. Almost all devices including Samsung, Huawei, Xiaomi, Oppo, Vivo are supported.
  - title: Non-root mode
    details: Use module without unlocking bootloader/root
  - title: Stable & Safe
    details: Minimum modification for Android Runtime, hard to be detected.
footer: Copyright © 2018-present weishu
---
